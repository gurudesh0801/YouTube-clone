1. First Install dependencies ------   npm install
2. Then run a project --------- npm run dev

